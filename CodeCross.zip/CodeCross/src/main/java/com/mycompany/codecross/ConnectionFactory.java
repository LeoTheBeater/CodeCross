/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.codecross;

/**
 *
 * @author rapha
 */
import java.sql.*;

public class ConnectionFactory {
    private static String host = "ep-fragrant-pond-758456.us-east-2.aws.neon.tech";
    private static String porta = "5432";
    private static String db = "Code_Cross_DB";
    private static String usuario = "RaphaelKameoka";
    private static String senha = "0Pn5pMWvBikS";
    
    public static Connection obterConexao() throws Exception{
        String s = String.format(
            "jdbc:postgresql://%s:%s/%s",
            host, porta, db
        );
        return DriverManager.getConnection(
            s, usuario, senha
        );
    }
}