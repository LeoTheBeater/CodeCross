/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.codecross;

/**
 *
 * @author rapha
 */

public class DAO {
    public void inserir(Usuario u)throws Exception{
        //especificar o comanod sql
        String sql = "INSERT INTO Usuarios (Nome_Usuario, Senha, Email) VALUES (?, ?, ?)";
        try(
            var conexao = ConnectionFactory.obterConexao();
            var ps = conexao.prepareStatement(sql);
        ){
            ps.setString(1, u.getNome());
            ps.setString(2, u.getSenha());
            ps.setString(3, u.getEmail());
            ps.executeUpdate();
        }
        //fechar os recuross 
    }

    public boolean existeNome (Usuario u) throws Exception{
        String sql = "SELECT nome_usuario, senha FROM usuarios WHERE nome_usuario = ? AND senha = ?;";
        try (
            var conexao = ConnectionFactory.obterConexao();
            var ps = conexao.prepareStatement(sql);
        ){
            ps.setString(1, u.getNome());
            ps.setString(2, u.getSenha());
            try(var rs = ps.executeQuery()){
                return rs.next();
            }
        }
    }
    public boolean existeEmail (Usuario u) throws Exception{
        String sql = "SELECT email, senha FROM usuarios WHERE email = ? AND senha = ?;";

        try (
            var conexao = ConnectionFactory.obterConexao();
            var ps = conexao.prepareStatement(sql);
        ){
            ps.setString(1, u.getEmail());
            ps.setString(2, u.getSenha());
            try(var rs = ps.executeQuery()){
                return rs.next();
            }
        }
    }
    public void alterarSenha (RedefinirSenha r)throws Exception{
        String sql = "UPDATE usuarios SET senha = ? WHERE email = ? ;";
        try (
            var conexao = ConnectionFactory.obterConexao();
            var ps = conexao.prepareStatement(sql);
        ){
            ps.setString(1, r.getSenha());
            ps.setString(2, r.getEmail());
            ps.executeUpdate();
        }
    }
}