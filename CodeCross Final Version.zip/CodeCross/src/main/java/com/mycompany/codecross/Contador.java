package com.mycompany.codecross;

import javax.swing.JTextField;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Classe responsável por implementar um contador de tempo.
 */
public class Contador {
    private JTextField jTextField6;
    private Timer timer;
    private int count;
    private boolean stopRequested;

    /**
     * Construtor da classe Contador.
     * @param jTextField6 Campo de texto onde o tempo será exibido.
     */
    public Contador(JTextField jTextField6) {
        this.jTextField6 = jTextField6;
        this.count = 0;
        this.stopRequested = false;

        ActionListener actionListener = new ActionListener() {
            /**
             * Método executado a cada intervalo de tempo do timer.
             * @param e Evento de ação.
             */
            public void actionPerformed(ActionEvent e) {
                count++;

                int minutes = count / 60;
                int seconds = count % 60;

                String formattedTime = String.format("%02d:%02d", minutes, seconds);
                jTextField6.setText(formattedTime);

                if (count >= 600 || stopRequested) { // 10 minutes or stop requested
                    stop();
                    jTextField6.setText("TEMPO ESGOTADO!");
                }
            }
        };

        timer = new Timer(1000, actionListener);
    }

    /**
     * Inicia o contador.
     */
    public void start() {
        timer.start();
    }

    /**
     * Para o contador.
     */
    public void stop() {
        timer.stop();
    }
}
