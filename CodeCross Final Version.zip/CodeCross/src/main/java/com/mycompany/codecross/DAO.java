package com.mycompany.codecross;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DAO {
    
    private JTable visor;
    
    public void setVisor(JTable visor) {
    this.visor = visor;
    }

    public void inserir(Usuario u) throws Exception {
        // Especificar o comando SQL
        String sql = "INSERT INTO Usuarios (nome_usuario, senha, email) VALUES (?, ?, ?)";
        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement ps = conexao.prepareStatement(sql);
        ) {
            ps.setString(1, u.getNome());
            ps.setString(2, u.getSenha());
            ps.setString(3, u.getEmail());
            ps.executeUpdate();
        } // Recursos serão fechados automaticamente
    }

    public void inserirRanking1(String nomeUsuario) throws Exception {
        // Obter o id do usuário
        int idUsuario = obterIdUsuario(nomeUsuario);

        // Especificar o comando SQL
        String sql = "INSERT INTO Ranking (id_fase, id_usuario, tempo) VALUES (1, ?, NULL)";
        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement ps = conexao.prepareStatement(sql);
        ) {
            ps.setInt(1, idUsuario);
            ps.executeUpdate();
        } // Recursos serão fechados automaticamente
    }

    public void inserirRanking2(String nomeUsuario) throws Exception {
        // Obter o id do usuário
        int idUsuario = obterIdUsuario(nomeUsuario);

        // Especificar o comando SQL
        String sql = "INSERT INTO Ranking (id_fase, id_usuario, tempo) VALUES (2, ?, NULL)";
        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement ps = conexao.prepareStatement(sql);
        ) {
            ps.setInt(1, idUsuario);
            ps.executeUpdate();
        } // Recursos serão fechados automaticamente
    }

    public void inserirRanking3(String nomeUsuario) throws Exception {
        // Obter o id do usuário
        int idUsuario = obterIdUsuario(nomeUsuario);

        // Especificar o comando SQL
        String sql = "INSERT INTO Ranking (id_fase, id_usuario, tempo) VALUES (3, ?, NULL)";
        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement ps = conexao.prepareStatement(sql);
        ) {
            ps.setInt(1, idUsuario);
            ps.executeUpdate();
        } // Recursos serão fechados automaticamente
    }

    private int obterIdUsuario(String nomeUsuario) throws Exception {
        // Especificar o comando SQL
        String sql = "SELECT id_usuario FROM Usuarios WHERE nome_usuario = ?";
        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement ps = conexao.prepareStatement(sql);
        ) {
            ps.setString(1, nomeUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_usuario");
                } else {
                    throw new Exception("Usuário não encontrado.");
                }
            }
        }
    }

    public void inserirRanking(Ranking ra) throws Exception {
        String sqlSelectTempUsuarios = "SELECT nome_usuario FROM TempUsuarios";
        String sqlSelectUsuarios = "SELECT id_usuario FROM Usuarios WHERE nome_usuario = ?";
        String sqlInsertRanking = "UPDATE Ranking SET tempo = ? WHERE id_usuario = ? AND id_fase= ?";
        String sqlDropTempUsuarios = "DROP TABLE TempUsuarios";

        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement psSelectTempUsuarios = conexao.prepareStatement(sqlSelectTempUsuarios);
            PreparedStatement psSelectUsuarios = conexao.prepareStatement(sqlSelectUsuarios);
            PreparedStatement psInsertRanking = conexao.prepareStatement(sqlInsertRanking);
            Statement stmtDropTempUsuarios = conexao.createStatement();
        ) {
            // Seleciona o nome de usuário da tabela TempUsuarios
            try (ResultSet rsTempUsuarios = psSelectTempUsuarios.executeQuery()) {
                if (rsTempUsuarios.next()) {
                    String nomeUsuario = rsTempUsuarios.getString("nome_usuario");

                    // Seleciona o ID do usuário na tabela Usuarios usando o nome de usuário
                    psSelectUsuarios.setString(1, nomeUsuario);
                    try (ResultSet rsUsuarios = psSelectUsuarios.executeQuery()) {
                        if (rsUsuarios.next()) {
                            int idUsuario = rsUsuarios.getInt("id_usuario");
                            // Insere o tempo em Ranking usando o ID do usuário
                            psInsertRanking.setString(1, ra.getTempo());
                            psInsertRanking.setInt(2, idUsuario);
                            psInsertRanking.setInt(3, ra.getFase());
                            psInsertRanking.executeUpdate();
                            System.out.println("certo");

                            // Drop table TempUsuarios
                            stmtDropTempUsuarios.executeUpdate(sqlDropTempUsuarios);
                        } else {
                            System.out.println("errado");
                            throw new Exception("Usuário não encontrado");
                        }
                    }
                } else {
                    System.out.println("errado");
                    throw new Exception("Nenhum usuário encontrado em TempUsuarios");
                }
            }
        }
    }
    public DefaultTableModel exiberRanking(String tabela) throws Exception {
        String sql = "SELECT ROW_NUMBER() OVER(ORDER BY tempo DESC) AS posicao, Usuarios.nome_usuario, Ranking.tempo " +
            "FROM Ranking " +
            "INNER JOIN Usuarios ON Ranking.id_usuario = Usuarios.id_usuario " +
            "WHERE Ranking.id_fase = 1 AND Ranking.tempo is NOT NULL " +
            "ORDER BY Ranking.tempo DESC";

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Posição");
        model.addColumn("Nome de Usuário");
        model.addColumn("Tempo");

        try (Connection conexao = ConnectionFactory.obterConexao();
            Statement st = conexao.createStatement();
            ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                String[] dados = new String[3];
                dados[0] = rs.getString(1);
                dados[1] = rs.getString(2);
                dados[2] = rs.getString(3);
                model.addRow(dados);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error" + e.toString());
        }

        return model;
    }
    public boolean existeNome(Usuario u) throws Exception {
        String sql = "SELECT nome_usuario, senha FROM Usuarios WHERE nome_usuario = ? AND senha = ?";
        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement ps = conexao.prepareStatement(sql);
        ) {
            ps.setString(1, u.getNome());
            ps.setString(2, u.getSenha());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public void criarETInserirTempUsuarios(String nomeUsuario) throws Exception {
        String sqlCreateTable = "CREATE TABLE TempUsuarios (id SERIAL PRIMARY KEY, nome_usuario VARCHAR(255))";
        String sqlInsert = "INSERT INTO TempUsuarios (nome_usuario) VALUES (?)";

        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement psCreateTable = conexao.prepareStatement(sqlCreateTable);
            PreparedStatement psInsert = conexao.prepareStatement(sqlInsert);
        ) {
            // Cria a tabela TempUsuarios
            psCreateTable.executeUpdate();

            // Insere o nome de usuário na tabela TempUsuarios
            psInsert.setString(1, nomeUsuario);
            psInsert.executeUpdate();
        }
    }

    public boolean existeEmail(Usuario u) throws Exception {
        String sql = "SELECT email, senha FROM Usuarios WHERE email = ? AND senha = ?";
        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement ps = conexao.prepareStatement(sql);
        ) {
            ps.setString(1, u.getEmail());
            ps.setString(2, u.getSenha());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public void alterarSenha(RedefinirSenha r) throws Exception {
        String sql = "UPDATE Usuarios SET senha = ? WHERE email = ?";
        try (
            Connection conexao = ConnectionFactory.obterConexao();
            PreparedStatement ps = conexao.prepareStatement(sql);
        ) {
            ps.setString(1, r.getSenha());
            ps.setString(2, r.getEmail());
            ps.executeUpdate();
        }
    }
}
