/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.codecross;

import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Nivel1 extends javax.swing.JFrame {
    private Contador contador;
    
    
    private Integer corretos = 0;
    
    private String objetoTextoAntigo1 = "";
    private String objetoTextoAntigo2 = "";
    private String objetoTextoAntigo3 = "";
    private String objetoTextoAntigo4 = "";
    private String objetoTextoAntigo5 = "";
    private String objetoTextoAntigo6 = "";
    
    private String classeTextoAntigo1 = "";
    private String classeTextoAntigo2 = "";
    private String classeTextoAntigo3 = "";
    private String classeTextoAntigo4 = "";
    private String classeTextoAntigo5 = "";
    //classeTextoAntigo6 esta junto do objetoTextoaAntigo4
    
    private String camelcaseTextoAntigo1 = "";
    private String camelcaseTextoAntigo2 = "";
    private String camelcaseTextoAntigo3 = "";
    private String camelcaseTextoAntigo4 = "";
    private String camelcaseTextoAntigo5 = "";
    private String camelcaseTextoAntigo6 = "";
    private String camelcaseTextoAntigo7 = "";
    //camelcaseTextoantigo8 esta junto do classeTextoAntigo4
    private String camelcaseTextoAntigo9 = "";
    
    private String herancaTextoAntigo1 = "";
    private String herancaTextoAntigo2 = "";
    private String herancaTextoAntigo3 = "";
    private String herancaTextoAntigo4 = "";
    private String herancaTextoAntigo5 = "";
    private String herancaTextoAntigo6 = "";
    //herancaTextAntigo7 esta junto do camelcaseTextoAntigo2
    
    //metodoTextoAntigo1 esta junto do camelcaseTextoAntigo3
    private String metodoTextoAntigo2 = "";
    private String metodoTextoAntigo3 = "";
    private String metodoTextoAntigo4 = "";
    private String metodoTextoAntigo5 = "";
    private String metodoTextoAntigo6 = "";
    
    private String privateTextoAntigo1 = "";
    private String privateTextoAntigo2 = "";
    private String privateTextoAntigo3 = "";
    private String privateTextoAntigo4 = "";
    //privateTextoAntigo5 esta junto do camelcaseTextoAntigo3
    private String privateTextoAntigo6 = "";
    private String privateTextoAntigo7 = "";
    
    private String booleanTextoAntigo1 = "";
    //booleanTextoAntigo2 esta junto do objetoTextoAntigo6
    private String booleanTextoAntigo3 = "";
    private String booleanTextoAntigo4 = "";
    private String booleanTextoAntigo5 = "";
    private String booleanTextoAntigo6 = "";
    private String booleanTextoAntigo7 = "";
    
    private String repeticaoTextoAntigo1 = "";
    private String repeticaoTextoAntigo2 = "";
    private String repeticaoTextoAntigo3 = "";
    private String repeticaoTextoAntigo4 = "";
    private String repeticaoTextoAntigo5 = "";
    private String repeticaoTextoAntigo6 = "";
    private String repeticaoTextoAntigo7 = "";
    private String repeticaoTextoAntigo8 = "";
    //repeticaoTextoAntigo9 esta junto de metodoTextoAntigo6
    
    //integerTextoAntigo2 esta junto de repeticaoTextoAntigo6
    private String integerTextoAntigo2 = "";
    private String integerTextoAntigo3 = "";
    private String integerTextoAntigo4 = "";
    private String integerTextoAntigo5 = "";
    private String integerTextoAntigo6 = "";
    private String integerTextoAntigo7 = "";
    
    private String selecaoTextoAntigo1 = "";
    private String selecaoTextoAntigo2 = "";
    private String selecaoTextoAntigo3 = "";
    //selecaoTextoAntigo4 esta junto de repeticaoTextoAntigo2
    private String selecaoTextoAntigo5 = "";
    private String selecaoTextoAntigo6 = "";
    private String selecaoTextoAntigo7= "";
    
    private String longTextoAntigo1 = "";
    //longTextAntigo2 esta junto de selecaoTextoAntigo7
    private String longTextoAntigo3 = "";
    private String longTextoAntigo4 = "";
    
    private String shortTextoAntigo1 = "";
    private String shortTextoAntigo2 = "";
    private String shortTextoAntigo3 = "";
    //shortTextoAntigo4 esta junto de integerTextoAntigo7
    private String shortTextoAntigo5 = "";
    
    


    //Para indentificar interseccoes:
    //valor 0 nao passou pela palavra e 1 passou
    Integer classeTextField5id = 0;
    Integer camelcaseTextField2id = 0;
    Integer camelcaseTextField7id = 0;
    Integer herancaTextField6id = 0;
    Integer privateTextField4id = 0;
    Integer booleanTextField1id = 0;
    Integer repeticaoTextField5id = 0;
    Integer selecaoTextField3id = 0;
    Integer longTextField1id = 0;
    Integer shortTextField3id = 0;

    //contador
    public JTextField getContadorTextField6() {
    return contadorTextField;
    }
    
    /**
     * Creates new form Nivel1
     */
    public Nivel1() {
        initComponents();
        objetoTextField1.setColumns(10);
        objetoTextField2.setColumns(10);
        objetoTextField3.setColumns(10);
        objetoClasseTextField46.setColumns(10);
        objetoTextField5.setColumns(10);
        objetoBooleanTextField62.setColumns(10);
        
        classeTextField1.setColumns(10);
        classeTextField2.setColumns(10);
        classeTextField3.setColumns(10);
        classeCamelcaseTextField48.setColumns(10);
        classeTextField5.setColumns(10);
        //classeTextField6 esta interseccionando com objetoTextField4
        
        camelcaseTextField1.setColumns(10);
        camelcaseHerancaTextField27.setColumns(10);
        camelcaseMetodoTextField31.setColumns(10);
        camelcaseTextField4.setColumns(10);
        camelcaseTextField5.setColumns(10);
        camelcaseTextField6.setColumns(10);
        camelcaseTextField7.setColumns(10);
        //camelcaseTextField8 esta interseccionando com classeTextField4
        camelcaseTextField9.setColumns(10);
        
        herancaTextField1.setColumns(10);
        herancaTextField2.setColumns(10);
        herancaTextField3.setColumns(10);
        privateHerancaTextField54.setColumns(10);
        herancaTextField5.setColumns(10);
        herancaTextField6.setColumns(10);
        //herancaTextField7 esta interseccionando com camelcaseTextField2
        
        //metodoTextField1 esta interseccionando com camelcaseTextField3
        metodoTextField2.setColumns(10);
        metodoTextField3.setColumns(10);
        metodoTextField4.setColumns(10);
        metodoTextField5.setColumns(10);
        repeticaoMetodoTextField96.setColumns(10);
        
        privateTextField1.setColumns(10);
        privateTextField2.setColumns(10);
        privateTextField3.setColumns(10);
        privateTextField4.setColumns(10);
        //privateTextField5 esta interseccionando com herancaTextField4
        privateTextField6.setColumns(10);
        privateTextField7.setColumns(10);
        
        booleanTextField1.setColumns(10);
        //booleanTextField2 esta interseccionando com objetoTextField6 
        booleanTextField3.setColumns(10);
        booleanTextField4.setColumns(10);
        booleanTextField5.setColumns(10);
        booleanTextField6.setColumns(10);
        booleanTextField7.setColumns(10);
        
        repeticaoTextField1.setColumns(10);
        repeticaoSelecaoTextField24.setColumns(10);
        repeticaoTextField3.setColumns(10);
        repeticaoTextField40.setColumns(10);
        repeticaoTextField5.setColumns(10);
        repeticaoIntegerTextField61.setColumns(10);
        repeticaoTextField7.setColumns(10);
        repeticaoTextField8.setColumns(10);
        //repeticaoTextField2 esta interseccionando com metodoTextField6
        
        //integerTextField1 esta interseccionando com repeticaoTextField6
        integerTextField2.setColumns(10);
        integerTextField3.setColumns(10);
        integerTextField4.setColumns(10);
        integerTextField5.setColumns(10);
        integerTextField6.setColumns(10);
        shortIntegerTextField47.setColumns(10);
        
        selecaoTextField1.setColumns(10);
        selecaoTextField2.setColumns(10);
        selecaoTextField3.setColumns(10);
        //selecaoTextField4 esta interseccionando com repeticaoTextField2
        selecaoTextField5.setColumns(10);
        selecaoTextField6.setColumns(10);
        longSelecaoTextField27.setColumns(10);
        
        longTextField1.setColumns(10);
        //longTextField2 esta interseccionando com selecaoTextField7
        longTextField3.setColumns(10);
        longTextField4.setColumns(10);
        
        shortTextField1.setColumns(10);
        shortTextField2.setColumns(10);
        shortTextField3.setColumns(10);
        //shortTextField4 esta interseccionando com integerTextField7
        shortTextField5.setColumns(10);

        
        
        
        
        contador = new Contador(contadorTextField); //Inicizalicao do objeto contador
        contadorTextField.setColumns(5);
        contador.start();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        repeticaoTextField4 = new javax.swing.JTextField();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        objetoTextField1 = new javax.swing.JTextField();
        objetoTextField2 = new javax.swing.JTextField();
        objetoTextField3 = new javax.swing.JTextField();
        objetoClasseTextField46 = new javax.swing.JTextField();
        objetoTextField5 = new javax.swing.JTextField();
        objetoBooleanTextField62 = new javax.swing.JTextField();
        classeTextField1 = new javax.swing.JTextField();
        classeTextField2 = new javax.swing.JTextField();
        classeTextField3 = new javax.swing.JTextField();
        classeCamelcaseTextField48 = new javax.swing.JTextField();
        classeTextField5 = new javax.swing.JTextField();
        camelcaseTextField1 = new javax.swing.JTextField();
        camelcaseHerancaTextField27 = new javax.swing.JTextField();
        camelcaseMetodoTextField31 = new javax.swing.JTextField();
        camelcaseTextField4 = new javax.swing.JTextField();
        camelcaseTextField5 = new javax.swing.JTextField();
        camelcaseTextField6 = new javax.swing.JTextField();
        camelcaseTextField7 = new javax.swing.JTextField();
        camelcaseTextField9 = new javax.swing.JTextField();
        contadorTextField = new javax.swing.JTextField();
        finalizarButton = new javax.swing.JButton();
        herancaTextField1 = new javax.swing.JTextField();
        herancaTextField2 = new javax.swing.JTextField();
        herancaTextField3 = new javax.swing.JTextField();
        privateHerancaTextField54 = new javax.swing.JTextField();
        herancaTextField5 = new javax.swing.JTextField();
        herancaTextField6 = new javax.swing.JTextField();
        metodoTextField2 = new javax.swing.JTextField();
        metodoTextField3 = new javax.swing.JTextField();
        metodoTextField4 = new javax.swing.JTextField();
        metodoTextField5 = new javax.swing.JTextField();
        repeticaoMetodoTextField96 = new javax.swing.JTextField();
        privateTextField1 = new javax.swing.JTextField();
        privateTextField2 = new javax.swing.JTextField();
        privateTextField3 = new javax.swing.JTextField();
        privateTextField4 = new javax.swing.JTextField();
        privateTextField6 = new javax.swing.JTextField();
        privateTextField7 = new javax.swing.JTextField();
        booleanTextField1 = new javax.swing.JTextField();
        booleanTextField3 = new javax.swing.JTextField();
        booleanTextField4 = new javax.swing.JTextField();
        booleanTextField5 = new javax.swing.JTextField();
        booleanTextField6 = new javax.swing.JTextField();
        booleanTextField7 = new javax.swing.JTextField();
        repeticaoTextField1 = new javax.swing.JTextField();
        repeticaoSelecaoTextField24 = new javax.swing.JTextField();
        repeticaoTextField3 = new javax.swing.JTextField();
        repeticaoTextField40 = new javax.swing.JTextField();
        repeticaoTextField5 = new javax.swing.JTextField();
        repeticaoIntegerTextField61 = new javax.swing.JTextField();
        repeticaoTextField7 = new javax.swing.JTextField();
        repeticaoTextField8 = new javax.swing.JTextField();
        integerTextField2 = new javax.swing.JTextField();
        integerTextField3 = new javax.swing.JTextField();
        integerTextField4 = new javax.swing.JTextField();
        integerTextField5 = new javax.swing.JTextField();
        integerTextField6 = new javax.swing.JTextField();
        shortIntegerTextField47 = new javax.swing.JTextField();
        selecaoTextField1 = new javax.swing.JTextField();
        selecaoTextField2 = new javax.swing.JTextField();
        selecaoTextField3 = new javax.swing.JTextField();
        selecaoTextField5 = new javax.swing.JTextField();
        selecaoTextField6 = new javax.swing.JTextField();
        longSelecaoTextField27 = new javax.swing.JTextField();
        longTextField1 = new javax.swing.JTextField();
        longTextField3 = new javax.swing.JTextField();
        longTextField4 = new javax.swing.JTextField();
        shortTextField1 = new javax.swing.JTextField();
        shortTextField2 = new javax.swing.JTextField();
        shortTextField5 = new javax.swing.JTextField();
        shortTextField3 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        dicasButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        planoFundoLabel = new javax.swing.JLabel();

        repeticaoTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                repeticaoTextField4ActionPerformed(evt);
            }
        });
        repeticaoTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoTextField4KeyPressed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        objetoTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                objetoTextField1ActionPerformed(evt);
            }
        });
        objetoTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                objetoTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(objetoTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 345, 30, 30));

        objetoTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                objetoTextField2ActionPerformed(evt);
            }
        });
        objetoTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                objetoTextField2KeyPressed(evt);
            }
        });
        getContentPane().add(objetoTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(426, 345, 30, 30));

        objetoTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                objetoTextField3ActionPerformed(evt);
            }
        });
        objetoTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                objetoTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(objetoTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 345, 30, 30));

        objetoClasseTextField46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                objetoClasseTextField46ActionPerformed(evt);
            }
        });
        objetoClasseTextField46.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                objetoClasseTextField46KeyPressed(evt);
            }
        });
        getContentPane().add(objetoClasseTextField46, new org.netbeans.lib.awtextra.AbsoluteConstraints(498, 345, 30, 30));

        objetoTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                objetoTextField5ActionPerformed(evt);
            }
        });
        objetoTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                objetoTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(objetoTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 345, 30, 30));

        objetoBooleanTextField62.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                objetoBooleanTextField62ActionPerformed(evt);
            }
        });
        objetoBooleanTextField62.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                objetoBooleanTextField62KeyPressed(evt);
            }
        });
        getContentPane().add(objetoBooleanTextField62, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 345, 30, 30));

        classeTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                classeTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(classeTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(498, 160, 30, 30));

        classeTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                classeTextField2KeyPressed(evt);
            }
        });
        getContentPane().add(classeTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(498, 201, 30, 30));

        classeTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                classeTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(classeTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(498, 237, 30, 30));

        classeCamelcaseTextField48.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                classeCamelcaseTextField48KeyPressed(evt);
            }
        });
        getContentPane().add(classeCamelcaseTextField48, new org.netbeans.lib.awtextra.AbsoluteConstraints(498, 273, 30, 30));

        classeTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                classeTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(classeTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(498, 309, 30, 30));

        camelcaseTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camelcaseTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(camelcaseTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(246, 273, 30, 30));

        camelcaseHerancaTextField27.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camelcaseHerancaTextField27KeyPressed(evt);
            }
        });
        getContentPane().add(camelcaseHerancaTextField27, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 273, 30, 30));

        camelcaseMetodoTextField31.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camelcaseMetodoTextField31KeyPressed(evt);
            }
        });
        getContentPane().add(camelcaseMetodoTextField31, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 273, 30, 30));

        camelcaseTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camelcaseTextField4KeyPressed(evt);
            }
        });
        getContentPane().add(camelcaseTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 273, 30, 30));

        camelcaseTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camelcaseTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(camelcaseTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 273, 30, 30));

        camelcaseTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camelcaseTextField6KeyPressed(evt);
            }
        });
        getContentPane().add(camelcaseTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(426, 273, 30, 30));

        camelcaseTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camelcaseTextField7KeyPressed(evt);
            }
        });
        getContentPane().add(camelcaseTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 273, 30, 30));

        camelcaseTextField9.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camelcaseTextField9KeyPressed(evt);
            }
        });
        getContentPane().add(camelcaseTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 273, 30, 30));

        contadorTextField.setBackground(new java.awt.Color(153, 153, 153));
        contadorTextField.setFont(new java.awt.Font("Segoe Script", 0, 24)); // NOI18N
        contadorTextField.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        contadorTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                contadorTextFieldFocusGained(evt);
            }
        });
        contadorTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contadorTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(contadorTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 130, 49));

        finalizarButton.setBackground(new java.awt.Color(153, 153, 153));
        finalizarButton.setText("FINALIZAR");
        finalizarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finalizarButtonActionPerformed(evt);
            }
        });
        getContentPane().add(finalizarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 670, 96, 30));

        herancaTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                herancaTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(herancaTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 40, 30, 30));

        herancaTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                herancaTextField2KeyPressed(evt);
            }
        });
        getContentPane().add(herancaTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 83, 30, 30));

        herancaTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                herancaTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(herancaTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 119, 30, 30));

        privateHerancaTextField54.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                privateHerancaTextField54KeyPressed(evt);
            }
        });
        getContentPane().add(privateHerancaTextField54, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 160, 30, 30));

        herancaTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                herancaTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(herancaTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 201, 30, 30));

        herancaTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                herancaTextField6KeyPressed(evt);
            }
        });
        getContentPane().add(herancaTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 237, 30, 30));

        metodoTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                metodoTextField2KeyPressed(evt);
            }
        });
        getContentPane().add(metodoTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 309, 30, 30));

        metodoTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                metodoTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(metodoTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 345, 30, 30));

        metodoTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                metodoTextField4KeyPressed(evt);
            }
        });
        getContentPane().add(metodoTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 381, 30, 30));

        metodoTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                metodoTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(metodoTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 417, 30, 30));

        repeticaoMetodoTextField96.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoMetodoTextField96KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoMetodoTextField96, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 453, 30, 30));

        privateTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                privateTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(privateTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 160, 30, 30));

        privateTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                privateTextField2KeyPressed(evt);
            }
        });
        getContentPane().add(privateTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(174, 160, 30, 30));

        privateTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                privateTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(privateTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 30, 30));

        privateTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                privateTextField4KeyPressed(evt);
            }
        });
        getContentPane().add(privateTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(246, 160, 30, 30));

        privateTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                privateTextField6KeyPressed(evt);
            }
        });
        getContentPane().add(privateTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 160, 30, 30));

        privateTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                privateTextField7KeyPressed(evt);
            }
        });
        getContentPane().add(privateTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 160, 30, 30));

        booleanTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booleanTextField1ActionPerformed(evt);
            }
        });
        booleanTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booleanTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(booleanTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 309, 30, 30));

        booleanTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booleanTextField3ActionPerformed(evt);
            }
        });
        booleanTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booleanTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(booleanTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 381, 30, 30));

        booleanTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booleanTextField4ActionPerformed(evt);
            }
        });
        booleanTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booleanTextField4KeyPressed(evt);
            }
        });
        getContentPane().add(booleanTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 417, 30, 30));

        booleanTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booleanTextField5ActionPerformed(evt);
            }
        });
        booleanTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booleanTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(booleanTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 453, 30, 30));

        booleanTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booleanTextField6ActionPerformed(evt);
            }
        });
        booleanTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booleanTextField6KeyPressed(evt);
            }
        });
        getContentPane().add(booleanTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 489, 30, 30));

        booleanTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booleanTextField7ActionPerformed(evt);
            }
        });
        booleanTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booleanTextField7KeyPressed(evt);
            }
        });
        getContentPane().add(booleanTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 525, 30, 30));

        repeticaoTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 453, 30, 30));

        repeticaoSelecaoTextField24.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoSelecaoTextField24KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoSelecaoTextField24, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 453, 30, 30));

        repeticaoTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(102, 453, 30, 30));

        repeticaoTextField40.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoTextField40KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoTextField40, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 453, 30, 30));

        repeticaoTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(174, 453, 30, 30));

        repeticaoIntegerTextField61.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoIntegerTextField61KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoIntegerTextField61, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 453, 30, 30));

        repeticaoTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoTextField7KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(246, 453, 30, 30));

        repeticaoTextField8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                repeticaoTextField8KeyPressed(evt);
            }
        });
        getContentPane().add(repeticaoTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 453, 30, 30));

        integerTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                integerTextField2KeyPressed(evt);
            }
        });
        getContentPane().add(integerTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 489, 30, 30));

        integerTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                integerTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(integerTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 525, 30, 30));

        integerTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                integerTextField4KeyPressed(evt);
            }
        });
        getContentPane().add(integerTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 561, 30, 30));

        integerTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                integerTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(integerTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 597, 30, 30));

        integerTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                integerTextField6KeyPressed(evt);
            }
        });
        getContentPane().add(integerTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 633, 30, 30));

        shortIntegerTextField47.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                shortIntegerTextField47KeyPressed(evt);
            }
        });
        getContentPane().add(shortIntegerTextField47, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 669, 30, 30));

        selecaoTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                selecaoTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(selecaoTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 345, 30, 30));

        selecaoTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                selecaoTextField2KeyPressed(evt);
            }
        });
        getContentPane().add(selecaoTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 381, 30, 30));

        selecaoTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                selecaoTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(selecaoTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 417, 30, 30));

        selecaoTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                selecaoTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(selecaoTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 489, 30, 30));

        selecaoTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                selecaoTextField6KeyPressed(evt);
            }
        });
        getContentPane().add(selecaoTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 525, 30, 30));

        longSelecaoTextField27.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                longSelecaoTextField27KeyPressed(evt);
            }
        });
        getContentPane().add(longSelecaoTextField27, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 561, 30, 30));

        longTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                longTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(longTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 561, 30, 30));

        longTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                longTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(longTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(102, 561, 30, 30));

        longTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                longTextField4KeyPressed(evt);
            }
        });
        getContentPane().add(longTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 561, 30, 30));

        shortTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                shortTextField1KeyPressed(evt);
            }
        });
        getContentPane().add(shortTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(102, 669, 30, 30));

        shortTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                shortTextField2KeyPressed(evt);
            }
        });
        getContentPane().add(shortTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 669, 30, 30));

        shortTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                shortTextField5KeyPressed(evt);
            }
        });
        getContentPane().add(shortTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(246, 669, 30, 30));

        shortTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                shortTextField3KeyPressed(evt);
            }
        });
        getContentPane().add(shortTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(174, 669, 30, 30));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("1.");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 155, 15, 40));

        dicasButton.setBackground(new java.awt.Color(153, 153, 153));
        dicasButton.setText("DICAS");
        dicasButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dicasButtonActionPerformed(evt);
            }
        });
        getContentPane().add(dicasButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 180, -1, -1));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("2.");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(292, 6, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("3.");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(231, 280, -1, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("4.");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(509, 133, 19, -1));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("5.");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 352, -1, -1));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("6.");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(582, 280, -1, -1));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("7.");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 460, -1, -1));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("8.");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 244, -1, -1));

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("9.");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 568, -1, -1));

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("10.");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(76, 316, 84, -1));

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("11.");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(81, 676, -1, -1));

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("12.");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 424, 66, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon("C:\\Users\\leona\\Downloads\\iconhead_1.png")); // NOI18N
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 20, 200, 100));

        jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\leona\\Downloads\\teste-removebg-preview_2.png")); // NOI18N
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, -230, 320, 400));

        planoFundoLabel.setIcon(new javax.swing.ImageIcon("C:\\Users\\leona\\Downloads\\552010.png")); // NOI18N
        getContentPane().add(planoFundoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 720));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void objetoTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_objetoTextField1ActionPerformed
    }//GEN-LAST:event_objetoTextField1ActionPerformed
    private void objetoTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_objetoTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_objetoTextField2ActionPerformed
    private void objetoTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_objetoTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_objetoTextField3ActionPerformed
    private void objetoClasseTextField46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_objetoClasseTextField46ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_objetoClasseTextField46ActionPerformed
    private void objetoTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_objetoTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_objetoTextField5ActionPerformed
    private void objetoBooleanTextField62ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_objetoBooleanTextField62ActionPerformed
    }//GEN-LAST:event_objetoBooleanTextField62ActionPerformed

    private void objetoTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_objetoTextField1KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (objetoTextoAntigo1.length() >= 0){
              objetoTextField1.setText(objetoTextoAntigo1.toUpperCase());
              objetoTextField2.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              objetoTextField1.setText("");
            }
            else{
              objetoTextoAntigo1 = objetoTextField1.getText();
              objetoTextField1.setText(objetoTextoAntigo1.toUpperCase());
              objetoTextField2.requestFocus();
            }
            
          }
          else{
              objetoTextoAntigo1 = "";
          }       
    }//GEN-LAST:event_objetoTextField1KeyPressed

    private void objetoTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_objetoTextField2KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (objetoTextoAntigo2.length() >= 0){
              objetoTextField2.setText(objetoTextoAntigo2.toUpperCase());
              objetoTextField3.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              objetoTextField2.setText("");
            }
            else{
              objetoTextoAntigo2 = objetoTextField2.getText();
              objetoTextField2.setText(objetoTextoAntigo2.toUpperCase());
              objetoTextField3.requestFocus();
            }
            
          }
          else{
              objetoTextoAntigo2 = "";
          }       
    }//GEN-LAST:event_objetoTextField2KeyPressed

    private void objetoTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_objetoTextField3KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (objetoTextoAntigo3.length() >= 0){
              objetoTextField3.setText(objetoTextoAntigo3.toUpperCase());
              objetoClasseTextField46.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              objetoTextField3.setText("");
            }
            else{
              objetoTextoAntigo3 = objetoTextField3.getText();
              objetoTextField3.setText(objetoTextoAntigo3.toUpperCase());
              objetoClasseTextField46.requestFocus();
            }
            
          }
          else{
              objetoTextoAntigo3 = "";
          }       
    }//GEN-LAST:event_objetoTextField3KeyPressed

    private void objetoClasseTextField46KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_objetoClasseTextField46KeyPressed
        //se a direcao for do objeto
        if (classeTextField5id < 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (objetoTextoAntigo4.length() >= 0){
                    objetoClasseTextField46.setText(objetoTextoAntigo4.toUpperCase());
                    objetoTextField5.requestFocus();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                    objetoClasseTextField46.setText("");
                }
                else{
                    objetoTextoAntigo4 = objetoClasseTextField46.getText();
                    objetoClasseTextField46.setText(objetoTextoAntigo4.toUpperCase());
                    objetoTextField5.requestFocus();
                }
            }
            else{
              objetoTextoAntigo4 = "";
            }    
        }
        //se a direcao for da classe
        else{
            objetoBooleanTextField62.getParent().requestFocusInWindow();
            objetoClasseTextField46.setText("");
        }
        classeTextField5id = 0;
    }//GEN-LAST:event_objetoClasseTextField46KeyPressed

    private void objetoTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_objetoTextField5KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (objetoTextoAntigo5.length() >= 0){
              objetoTextField5.setText(objetoTextoAntigo5.toUpperCase());
              objetoBooleanTextField62.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              objetoTextField5.setText("");
            }
            else{
              objetoTextoAntigo5 = objetoTextField5.getText();
              objetoTextField5.setText(objetoTextoAntigo5.toUpperCase());
              objetoBooleanTextField62.requestFocus();
            }
            
          }
          else{
              objetoTextoAntigo5 = "";
          }       
    }//GEN-LAST:event_objetoTextField5KeyPressed

    private void objetoBooleanTextField62KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_objetoBooleanTextField62KeyPressed
        if (booleanTextField1id != 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (objetoTextoAntigo6.length() >= 0){
                  objetoBooleanTextField62.setText(objetoTextoAntigo6.toUpperCase());
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  objetoBooleanTextField62.setText("");
                }
                else{
                  objetoTextoAntigo6 = objetoBooleanTextField62.getText();
                  objetoBooleanTextField62.setText(objetoTextoAntigo6.toUpperCase());
                }

              }
              else{
                  objetoTextoAntigo6 = "";
              }       
            objetoBooleanTextField62.getParent().requestFocusInWindow();
        }
        else {
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (objetoTextoAntigo6.length() >= 0){
              objetoBooleanTextField62.setText(objetoTextoAntigo6.toUpperCase());
              objetoBooleanTextField62.requestFocus();
              
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              booleanTextField3.setText("");
            }
            else{
              objetoTextoAntigo6 = objetoBooleanTextField62.getText();
              objetoBooleanTextField62.setText(objetoTextoAntigo6.toUpperCase());
              booleanTextField3.requestFocus();
              
            }
            
          }
          else{
              booleanTextoAntigo1 = "";
          }       
        }
        booleanTextField1id = 0;
    }//GEN-LAST:event_objetoBooleanTextField62KeyPressed

    private void classeTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_classeTextField1KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (classeTextoAntigo1.length() >= 0){
              classeTextField1.setText(classeTextoAntigo1.toUpperCase());
              classeTextField2.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              classeTextField1.setText("");
            }
            else{
              classeTextoAntigo1 = classeTextField1.getText();
              classeTextField1.setText(classeTextoAntigo1.toUpperCase());
              classeTextField2.requestFocus();
            }
            
          }
          else{
              classeTextoAntigo1 = "";
          }       
    }//GEN-LAST:event_classeTextField1KeyPressed

    private void classeTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_classeTextField2KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (classeTextoAntigo2.length() >= 0){
              classeTextField2.setText(classeTextoAntigo2.toUpperCase());
              classeTextField3.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              classeTextField2.setText("");
            }
            else{
              classeTextoAntigo2 = classeTextField2.getText();
              classeTextField2.setText(classeTextoAntigo2.toUpperCase());
              classeTextField3.requestFocus();
            }
            
          }
          else{
              classeTextoAntigo2 = "";
          }       
    }//GEN-LAST:event_classeTextField2KeyPressed

    private void classeTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_classeTextField3KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (classeTextoAntigo3.length() >= 0){
              classeTextField3.setText(classeTextoAntigo3.toUpperCase());
              classeCamelcaseTextField48.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              classeTextField3.setText("");
            }
            else{
              classeTextoAntigo3 = classeTextField3.getText();
              classeTextField3.setText(classeTextoAntigo3.toUpperCase());
              classeCamelcaseTextField48.requestFocus();
            }
            
          }
          else{
              classeTextoAntigo3 = "";
          }       
    }//GEN-LAST:event_classeTextField3KeyPressed

    private void classeCamelcaseTextField48KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_classeCamelcaseTextField48KeyPressed

        if (camelcaseTextField7id < 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (classeTextoAntigo4.length() >= 0){
                    classeCamelcaseTextField48.setText(classeTextoAntigo4.toUpperCase());
                    classeTextField5.requestFocus();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                    classeCamelcaseTextField48.setText("");
                }
                else{
                    classeTextoAntigo4 = classeCamelcaseTextField48.getText();
                    classeCamelcaseTextField48.setText(classeTextoAntigo4.toUpperCase());
                    classeTextField5.requestFocus();
                }
            }
            else{
              classeTextoAntigo4 = "";
            }    
        }
        //se a direcao for do camelcase
        else{
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (classeTextoAntigo4.length() >= 0){
              classeCamelcaseTextField48.setText(classeTextoAntigo4.toUpperCase());
              camelcaseTextField9.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              classeCamelcaseTextField48.setText("");
            }
            else{
              classeTextoAntigo4 = classeCamelcaseTextField48.getText();
              classeCamelcaseTextField48.setText(classeTextoAntigo4.toUpperCase());
              camelcaseTextField9.requestFocus();
            }
            
          }
          else{
              classeTextoAntigo4 = "";
          }    
        }
        camelcaseTextField7id = 0;

    }//GEN-LAST:event_classeCamelcaseTextField48KeyPressed
  
    private void classeTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_classeTextField5KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (classeTextoAntigo5.length() >= 0){
              classeTextField5.setText(classeTextoAntigo5.toUpperCase());
              objetoClasseTextField46.requestFocus();
              classeTextField5id = 1;
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              classeTextField5.setText("");
            }
            else{
              classeTextoAntigo5 = classeTextField5.getText();
              classeTextField5.setText(classeTextoAntigo5.toUpperCase());
              objetoClasseTextField46.requestFocus();
            }
            
          }
          else{
              classeTextoAntigo5 = "";
          }       
        
    }//GEN-LAST:event_classeTextField5KeyPressed

    private void camelcaseTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camelcaseTextField1KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (camelcaseTextoAntigo1.length() >= 0){
              camelcaseTextField1.setText(camelcaseTextoAntigo1.toUpperCase());
              camelcaseHerancaTextField27.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              camelcaseTextField1.setText("");
            }
            else{
              camelcaseTextoAntigo1 = camelcaseTextField1.getText();
              camelcaseTextField1.setText(camelcaseTextoAntigo1.toUpperCase());
              camelcaseHerancaTextField27.requestFocus();
            }
            
          }
          else{
              camelcaseTextoAntigo1 = "";
          }       
    }//GEN-LAST:event_camelcaseTextField1KeyPressed

    private void camelcaseHerancaTextField27KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camelcaseHerancaTextField27KeyPressed

        //se a direcao for do camelcase
        if (herancaTextField6id < 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (camelcaseTextoAntigo2.length() >= 0){
                  camelcaseHerancaTextField27.setText(camelcaseTextoAntigo2.toUpperCase());
                  camelcaseMetodoTextField31.requestFocus();
                  camelcaseTextField2id = 1;
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  camelcaseHerancaTextField27.setText("");
                }
                else{
                  camelcaseTextoAntigo2 = camelcaseHerancaTextField27.getText();
                  camelcaseHerancaTextField27.setText(camelcaseTextoAntigo2.toUpperCase());
                  camelcaseMetodoTextField31.requestFocus();
                }

              }
              else{
                  camelcaseTextoAntigo2 = "";
              }
        }
        //se a direcao for de heranca
        else{
            camelcaseHerancaTextField27.getParent().requestFocusInWindow();
            camelcaseHerancaTextField27.setText("");
        }
        herancaTextField6id = 0;
    }//GEN-LAST:event_camelcaseHerancaTextField27KeyPressed

    private void camelcaseMetodoTextField31KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camelcaseMetodoTextField31KeyPressed
        // TODO add your handling code here:
        //se a direcao for do metodo
        if (camelcaseTextField2id < 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (camelcaseTextoAntigo3.length() >= 0){
                    camelcaseMetodoTextField31.setText(camelcaseTextoAntigo3.toUpperCase());
                    metodoTextField2.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              camelcaseMetodoTextField31.setText("");
            }
            else{
              camelcaseTextoAntigo3 = camelcaseMetodoTextField31.getText();
              camelcaseMetodoTextField31.setText(camelcaseTextoAntigo3.toUpperCase());
              metodoTextField2.requestFocus();
            }
            
          }
          else{
              camelcaseTextoAntigo3 = "";
          }     
        }
        //se a direcao for do camelcase
        else{
            
          if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (camelcaseTextoAntigo3.length() >= 0){
                  camelcaseMetodoTextField31.setText(camelcaseTextoAntigo3.toUpperCase());
                  camelcaseTextField4.requestFocus();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  camelcaseMetodoTextField31.setText("");
                }
                else{
                  camelcaseTextoAntigo3 = camelcaseMetodoTextField31.getText();
                  camelcaseMetodoTextField31.setText(camelcaseTextoAntigo3.toUpperCase());
                  camelcaseTextField4.requestFocus();
                }

              }
              else{
                  camelcaseTextoAntigo3 = "";
              }    
                    
            
            
            
            
        }
    }//GEN-LAST:event_camelcaseMetodoTextField31KeyPressed

    private void camelcaseTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camelcaseTextField4KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (camelcaseTextoAntigo4.length() >= 0){
              camelcaseTextField4.setText(camelcaseTextoAntigo4.toUpperCase());
              camelcaseTextField5.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              camelcaseTextField4.setText("");
            }
            else{
              camelcaseTextoAntigo4 = camelcaseTextField4.getText();
              camelcaseTextField4.setText(camelcaseTextoAntigo4.toUpperCase());
              camelcaseTextField5.requestFocus();
            }
            
          }
          else{
              camelcaseTextoAntigo4 = "";
          }    
    }//GEN-LAST:event_camelcaseTextField4KeyPressed

    private void camelcaseTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camelcaseTextField5KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (camelcaseTextoAntigo5.length() >= 0){
              camelcaseTextField5.setText(camelcaseTextoAntigo5.toUpperCase());
              camelcaseTextField6.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              camelcaseTextField5.setText("");
            }
            else{
              camelcaseTextoAntigo5 = camelcaseTextField5.getText();
              camelcaseTextField5.setText(camelcaseTextoAntigo5.toUpperCase());
              camelcaseTextField6.requestFocus();
            }
            
          }
          else{
              camelcaseTextoAntigo5 = "";
          }    
    }//GEN-LAST:event_camelcaseTextField5KeyPressed

    private void camelcaseTextField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camelcaseTextField6KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (camelcaseTextoAntigo6.length() >= 0){
              camelcaseTextField6.setText(camelcaseTextoAntigo6.toUpperCase());
              camelcaseTextField7.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              camelcaseTextField6.setText("");
            }
            else{
              camelcaseTextoAntigo6 = camelcaseTextField6.getText();
              camelcaseTextField6.setText(camelcaseTextoAntigo6.toUpperCase());
              camelcaseTextField7.requestFocus();
            }
            
          }
          else{
              camelcaseTextoAntigo6 = "";
          }    
    }//GEN-LAST:event_camelcaseTextField6KeyPressed

    private void camelcaseTextField7KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camelcaseTextField7KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (camelcaseTextoAntigo7.length() >= 0){
              camelcaseTextField7.setText(camelcaseTextoAntigo7.toUpperCase());
              classeCamelcaseTextField48.requestFocus();
              camelcaseTextField7id = 1;
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              camelcaseTextField7.setText("");
            }
            else{
              camelcaseTextoAntigo7 = camelcaseTextField7.getText();
              camelcaseTextField7.setText(camelcaseTextoAntigo7.toUpperCase());
              classeCamelcaseTextField48.requestFocus();
            }
            
          }
          else{
              camelcaseTextoAntigo7 = "";
          }    
        
    }//GEN-LAST:event_camelcaseTextField7KeyPressed

    private void camelcaseTextField9KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camelcaseTextField9KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (camelcaseTextoAntigo9.length() >= 0){
              camelcaseTextField9.setText(camelcaseTextoAntigo9.toUpperCase());
              camelcaseTextField9.getParent().requestFocusInWindow();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              camelcaseTextField9.setText("");
            }
            else{
              camelcaseTextoAntigo9 = camelcaseTextField9.getText();
              camelcaseTextField9.setText(camelcaseTextoAntigo9.toUpperCase());
              camelcaseTextField9.getParent().requestFocusInWindow();
            }
          }
          else{
              camelcaseTextoAntigo9 = "";
          }    
    }//GEN-LAST:event_camelcaseTextField9KeyPressed

    private void contadorTextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_contadorTextFieldFocusGained
        // TODO add your handling code here:
        contadorTextField.getParent().requestFocusInWindow();
    }//GEN-LAST:event_contadorTextFieldFocusGained

    private void finalizarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finalizarButtonActionPerformed
        
        String objetoFormado = objetoTextField1.getText().toUpperCase()
            + objetoTextField2.getText().toUpperCase()
            + objetoTextField3.getText().toUpperCase()
            + objetoClasseTextField46.getText().toUpperCase()
            + objetoTextField5.getText().toUpperCase()
            + objetoBooleanTextField62.getText().toUpperCase();
        
        String classeFormado = classeTextField1.getText().toUpperCase()
            + classeTextField2.getText().toUpperCase()
            + classeTextField3.getText().toUpperCase()
            + classeCamelcaseTextField48.getText().toUpperCase()
            + classeTextField5.getText().toUpperCase()
            + objetoClasseTextField46.getText().toUpperCase();
        
        String camelcaseFormado = camelcaseTextField1.getText().toUpperCase()
            + camelcaseHerancaTextField27.getText().toUpperCase()
            + camelcaseMetodoTextField31.getText().toUpperCase()
            + camelcaseTextField4.getText().toUpperCase()
            + camelcaseTextField5.getText().toUpperCase()
            + camelcaseTextField6.getText().toUpperCase()
            + camelcaseTextField7.getText().toUpperCase()
            + classeCamelcaseTextField48.getText().toUpperCase()
            + camelcaseTextField9.getText().toUpperCase();
        
        String herancaFormado = herancaTextField1.getText().toUpperCase()
            + herancaTextField2.getText().toUpperCase()
            + herancaTextField3.getText().toUpperCase()
            + privateHerancaTextField54.getText().toUpperCase()
            + herancaTextField5.getText().toUpperCase()
            + herancaTextField6.getText().toUpperCase()
            + camelcaseHerancaTextField27.getText().toUpperCase();
        
        String metodoFormado = camelcaseMetodoTextField31.getText().toUpperCase()
            + metodoTextField2.getText().toUpperCase()
            + metodoTextField3.getText().toUpperCase()
            + metodoTextField4.getText().toUpperCase()
            + metodoTextField5.getText().toUpperCase()
            + repeticaoMetodoTextField96.getText().toUpperCase();
        
        String privateFormado = privateTextField1.getText().toUpperCase()
            + privateTextField2.getText().toUpperCase()
            + privateTextField3.getText().toUpperCase()
            + privateTextField4.getText().toUpperCase()
            + privateHerancaTextField54.getText().toUpperCase()
            + privateTextField6.getText().toUpperCase()
            + privateTextField7.getText().toUpperCase();
        
        String booleanFormado = booleanTextField1.getText().toUpperCase()
            + objetoBooleanTextField62.getText().toUpperCase()
            + booleanTextField3.getText().toUpperCase()
            + booleanTextField4.getText().toUpperCase()
            + booleanTextField5.getText().toUpperCase()
            + booleanTextField6.getText().toUpperCase()
            + booleanTextField7.getText().toUpperCase();
        
        String repeticaoFormado = repeticaoTextField1.getText().toUpperCase()
            + repeticaoSelecaoTextField24.getText().toUpperCase()
            + repeticaoTextField3.getText().toUpperCase()
            + repeticaoTextField40.getText().toUpperCase()
            + repeticaoTextField5.getText().toUpperCase()
            + repeticaoIntegerTextField61.getText().toUpperCase()
            + repeticaoTextField7.getText().toUpperCase()
            + repeticaoTextField8.getText().toUpperCase()
            + repeticaoMetodoTextField96.getText().toUpperCase();
        
        String integerFormado = repeticaoIntegerTextField61.getText().toUpperCase()
            + integerTextField2.getText().toUpperCase()
            + integerTextField3.getText().toUpperCase()
            + integerTextField4.getText().toUpperCase()
            + integerTextField5.getText().toUpperCase()
            + integerTextField6.getText().toUpperCase()
            + shortIntegerTextField47.getText().toUpperCase();
        
        String selecaoFormado = selecaoTextField1.getText().toUpperCase()
            + selecaoTextField2.getText().toUpperCase()
            + selecaoTextField3.getText().toUpperCase()
            + repeticaoSelecaoTextField24.getText().toUpperCase()
            + selecaoTextField5.getText().toUpperCase()
            + selecaoTextField6.getText().toUpperCase()
            + longSelecaoTextField27.getText().toUpperCase();
        
        String longFormado = longTextField1.getText().toUpperCase()
            + longSelecaoTextField27.getText().toUpperCase()
            + longTextField3.getText().toUpperCase()
            + longTextField4.getText().toUpperCase();
        
        String shortFormado = shortTextField1.getText().toUpperCase()
            + shortTextField2.getText().toUpperCase()
            + shortTextField3.getText().toUpperCase()
            + shortIntegerTextField47.getText().toUpperCase()
            + shortTextField5.getText().toUpperCase();



        Integer corretos = 12;

        String mensagem = "";
        if (!privateFormado.equals("PRIVATE")){
            mensagem += "A palavra 1 está incorreta\n";
            corretos --;
        }
        if (!herancaFormado.equals("HERANCA")){
            mensagem += "A palavra 2 está incorreta\n";
            corretos --;
        }
        if (!camelcaseFormado.equals("CAMELCASE")){
            mensagem += "A palavra 3 está incorreta\n";
            corretos --;
        }
        if (!classeFormado.equals("CLASSE")) {
            mensagem += "A palavra 4 está incorreta\n";
            corretos --;
        }
        if (!objetoFormado.equals("OBJETO")) {
            mensagem += "A palavra 5 está incorreta\n";
            corretos --;
        }
        if (!booleanFormado.equals("BOOLEAN")){
            mensagem += "A palavra 6 está incorreta\n";
            corretos --;
        }
        if (!repeticaoFormado.equals("REPETICAO")){
            mensagem += "A palavra 7 está incorreta\n";
            corretos --;
        }
        if (!metodoFormado.equals("METODO")){
            mensagem += "A palavra 8 está incorreta\n";
            corretos --;
        }
        if (!longFormado.equals("LONG")){
            mensagem += "A palavra 9 está incorreta\n";
            corretos --;
        }
        if (!selecaoFormado.equals("SELECAO")){
            mensagem += "A palavra 10 está incorreta\n";
            corretos --;
        }
        if (!shortFormado.equals("SHORT")){
            mensagem += "A palavra 11 está incorreta\n";
            corretos --;
        }
        if (!integerFormado.equals("INTEGER")){
            mensagem += "A palavra 12 está incorreta\n";
            corretos --;
        }

        if (corretos == 12) {
            contador.stop();
            Musica musica = new Musica();
            musica.musica("C:\\Users\\leona\\OneDrive\\Documents\\NetBeansProjects\\CodeCross\\src\\main\\java\\com\\mycompany\\codecross\\Correct sound effect 正確音效-YoutubeConvert.cc.wav");
            String contador = contadorTextField.getText();
            int totalSegundos = 0;
            if (contador.equals("TEMPO ESGOTADO!")){
                totalSegundos = 600;
            }
            else{
                String[] partes = contador.split(":");
                int minutos = Integer.parseInt(partes[0]);
                int segundos = Integer.parseInt(partes[1]);
                totalSegundos = minutos * 60 + segundos;
            }
            String tempo = String.valueOf(totalSegundos);
            
            Ranking ra = new Ranking(1, tempo);
            DAO dao = new DAO();
            try {    
                dao.inserirRanking(ra);
            } catch (Exception ex) {
                Logger.getLogger(Nivel1.class.getName()).log(Level.SEVERE, null, ex);
            }
            var dt = new RankingTela();
            dt.setVisible(true);
            dispose();
            
        } 
        else {
            Musica musica = new Musica();
            musica.musica("C:\\Users\\leona\\OneDrive\\Documents\\NetBeansProjects\\CodeCross\\src\\main\\java\\com\\mycompany\\codecross\\Wrong Answer Sound effect-YoutubeConvert.cc.wav");
            JOptionPane.showMessageDialog(null, mensagem);
        }
        
              
        
        
        
        
    }//GEN-LAST:event_finalizarButtonActionPerformed

    private void repeticaoTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_repeticaoTextField4ActionPerformed
        
    }//GEN-LAST:event_repeticaoTextField4ActionPerformed

    private void repeticaoTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoTextField4KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_repeticaoTextField4KeyPressed

    private void herancaTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_herancaTextField1KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (herancaTextoAntigo1.length() >= 0){
              herancaTextField1.setText(herancaTextoAntigo1.toUpperCase());
              herancaTextField2.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              herancaTextField1.setText("");
            }
            else{
              herancaTextoAntigo1 = herancaTextField1.getText();
              herancaTextField1.setText(herancaTextoAntigo1.toUpperCase());
              herancaTextField2.requestFocus();
            }
            
          }
          else{
              herancaTextoAntigo1 = "";
          }       
    }//GEN-LAST:event_herancaTextField1KeyPressed

    private void herancaTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_herancaTextField2KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (herancaTextoAntigo2.length() >= 0){
              herancaTextField2.setText(herancaTextoAntigo2.toUpperCase());
              herancaTextField3.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              herancaTextField2.setText("");
            }
            else{
              herancaTextoAntigo2 = herancaTextField2.getText();
              herancaTextField2.setText(herancaTextoAntigo2.toUpperCase());
              herancaTextField3.requestFocus();
            }
            
          }
          else{
              herancaTextoAntigo2 = "";
          }       
    }//GEN-LAST:event_herancaTextField2KeyPressed

    private void herancaTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_herancaTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (herancaTextoAntigo3.length() >= 0){
              herancaTextField3.setText(herancaTextoAntigo3.toUpperCase());
              privateHerancaTextField54.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              herancaTextField3.setText("");
            }
            else{
              herancaTextoAntigo3 = herancaTextField3.getText();
              herancaTextField3.setText(herancaTextoAntigo3.toUpperCase());
              privateHerancaTextField54.requestFocus();
            }
            
          }
          else{
              herancaTextoAntigo3 = "";
          }       
    }//GEN-LAST:event_herancaTextField3KeyPressed

    private void privateHerancaTextField54KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_privateHerancaTextField54KeyPressed
        //se a direcao for da heranca
        if (privateTextField4id < 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (herancaTextoAntigo4.length() >= 0){
                  privateHerancaTextField54.setText(herancaTextoAntigo4.toUpperCase());
                  herancaTextField5.requestFocus();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  privateHerancaTextField54.setText("");
                }
                else{
                  herancaTextoAntigo4 = privateHerancaTextField54.getText();
                  privateHerancaTextField54.setText(herancaTextoAntigo4.toUpperCase());
                  herancaTextField5.requestFocus();
                }

              }
              else{
                  herancaTextoAntigo4 = "";
              }       
        }
        //se a direcao for do private
        else {
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (herancaTextoAntigo4.length() >= 0){
              privateHerancaTextField54.setText(herancaTextoAntigo4.toUpperCase());
              privateTextField6.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              privateHerancaTextField54.setText("");
            }
            else{
              herancaTextoAntigo4 = privateHerancaTextField54.getText();
              privateHerancaTextField54.setText(herancaTextoAntigo4.toUpperCase());
              privateTextField6.requestFocus();
            }
            
          }
          else{
              herancaTextoAntigo4 = "";
          }       
        }
        privateTextField4id = 0;
    }//GEN-LAST:event_privateHerancaTextField54KeyPressed

    private void herancaTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_herancaTextField5KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (herancaTextoAntigo5.length() >= 0){
              herancaTextField5.setText(herancaTextoAntigo5.toUpperCase());
              herancaTextField6.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              herancaTextField5.setText("");
            }
            else{
              herancaTextoAntigo5 = herancaTextField5.getText();
              herancaTextField5.setText(herancaTextoAntigo5.toUpperCase());
              herancaTextField6.requestFocus();
            }
            
          }
          else{
              herancaTextoAntigo5 = "";
          }       
    }//GEN-LAST:event_herancaTextField5KeyPressed

    private void herancaTextField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_herancaTextField6KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (herancaTextoAntigo6.length() >= 0){
              herancaTextField6.setText(herancaTextoAntigo6.toUpperCase());
              camelcaseHerancaTextField27.requestFocus();
              herancaTextField6id = 1;
              
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              herancaTextField6.setText("");
            }
            else{
              herancaTextoAntigo6 = herancaTextField6.getText();
              herancaTextField6.setText(herancaTextoAntigo6.toUpperCase());
              camelcaseHerancaTextField27.requestFocus();
            }
            
          }
          else{
              herancaTextoAntigo6 = "";
          }       
    }//GEN-LAST:event_herancaTextField6KeyPressed

    private void metodoTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_metodoTextField2KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (metodoTextoAntigo2.length() >= 0){
              metodoTextField2.setText(metodoTextoAntigo2.toUpperCase());
              metodoTextField3.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              metodoTextField2.setText("");
            }
            else{
              metodoTextoAntigo2 = metodoTextField2.getText();
              metodoTextField2.setText(metodoTextoAntigo2.toUpperCase());
              metodoTextField3.requestFocus();
            }
            
          }
          else{
              metodoTextoAntigo2 = "";
          }       
    }//GEN-LAST:event_metodoTextField2KeyPressed

    private void metodoTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_metodoTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (metodoTextoAntigo3.length() >= 0){
              metodoTextField3.setText(metodoTextoAntigo3.toUpperCase());
              metodoTextField4.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              metodoTextField3.setText("");
            }
            else{
              metodoTextoAntigo3 = metodoTextField3.getText();
              metodoTextField3.setText(metodoTextoAntigo3.toUpperCase());
              metodoTextField4.requestFocus();
            }
            
          }
          else{
              metodoTextoAntigo3 = "";
          }       
    }//GEN-LAST:event_metodoTextField3KeyPressed

    private void metodoTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_metodoTextField4KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (metodoTextoAntigo4.length() >= 0){
              metodoTextField4.setText(metodoTextoAntigo4.toUpperCase());
              metodoTextField5.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              metodoTextField4.setText("");
            }
            else{
              metodoTextoAntigo4 = metodoTextField4.getText();
              metodoTextField4.setText(metodoTextoAntigo4.toUpperCase());
              metodoTextField5.requestFocus();
            }
            
          }
          else{
              metodoTextoAntigo4 = "";
          }       
    }//GEN-LAST:event_metodoTextField4KeyPressed

    private void metodoTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_metodoTextField5KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (metodoTextoAntigo5.length() >= 0){
              metodoTextField5.setText(metodoTextoAntigo5.toUpperCase());
              repeticaoMetodoTextField96.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              metodoTextField5.setText("");
            }
            else{
              metodoTextoAntigo5 = metodoTextField5.getText();
              metodoTextField5.setText(metodoTextoAntigo5.toUpperCase());
              repeticaoMetodoTextField96.requestFocus();
            }
            
          }
          else{
              metodoTextoAntigo5 = "";
          }       
    }//GEN-LAST:event_metodoTextField5KeyPressed

    private void repeticaoMetodoTextField96KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoMetodoTextField96KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (metodoTextoAntigo6.length() >= 0){
              repeticaoMetodoTextField96.setText(metodoTextoAntigo5.toUpperCase());
              repeticaoMetodoTextField96.getParent().requestFocusInWindow();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoMetodoTextField96.setText("");
            }
            else{
              metodoTextoAntigo6 = repeticaoMetodoTextField96.getText();
              repeticaoMetodoTextField96.setText(metodoTextoAntigo6.toUpperCase());
              objetoBooleanTextField62.getParent().requestFocusInWindow();
            }
            
          }
          else{
              metodoTextoAntigo6 = "";
          }       
    }//GEN-LAST:event_repeticaoMetodoTextField96KeyPressed

    private void privateTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_privateTextField1KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (privateTextoAntigo1.length() >= 0){
              privateTextField1.setText(privateTextoAntigo1.toUpperCase());
              privateTextField2.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              privateTextField1.setText("");
            }
            else{
              privateTextoAntigo1 = privateTextField1.getText();
              privateTextField1.setText(privateTextoAntigo1.toUpperCase());
              privateTextField2.requestFocus();
            }
            
          }
          else{
              privateTextoAntigo1 = "";
          }       
    }//GEN-LAST:event_privateTextField1KeyPressed

    private void privateTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_privateTextField2KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (privateTextoAntigo2.length() >= 0){
              privateTextField2.setText(privateTextoAntigo2.toUpperCase());
              privateTextField3.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              privateTextField2.setText("");
            }
            else{
              privateTextoAntigo2 = privateTextField2.getText();
              privateTextField2.setText(privateTextoAntigo2.toUpperCase());
              privateTextField3.requestFocus();
            }
            
          }
          else{
              privateTextoAntigo2 = "";
          }       
    }//GEN-LAST:event_privateTextField2KeyPressed

    private void privateTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_privateTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (privateTextoAntigo3.length() >= 0){
              privateTextField3.setText(privateTextoAntigo3.toUpperCase());
              privateTextField4.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              privateTextField3.setText("");
            }
            else{
              privateTextoAntigo3 = privateTextField3.getText();
              privateTextField3.setText(privateTextoAntigo3.toUpperCase());
              privateTextField4.requestFocus();
            }
            
          }
          else{
              privateTextoAntigo3 = "";
          }       
    }//GEN-LAST:event_privateTextField3KeyPressed

    private void privateTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_privateTextField4KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            privateTextField4id = 1;
            if (privateTextoAntigo4.length() >= 0){
              privateTextField4.setText(privateTextoAntigo4.toUpperCase());
              privateTextField4.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              privateHerancaTextField54.setText("");
            }
            else{
              privateTextoAntigo4 = privateTextField4.getText();
              privateTextField4.setText(privateTextoAntigo4.toUpperCase());
              privateHerancaTextField54.requestFocus();
            }
            
          }
          else{
              privateTextoAntigo4 = "";
          }       
    }//GEN-LAST:event_privateTextField4KeyPressed

    private void privateTextField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_privateTextField6KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (privateTextoAntigo6.length() >= 0){
              privateTextField6.setText(privateTextoAntigo6.toUpperCase());
              privateTextField7.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              privateTextField6.setText("");
            }
            else{
              privateTextoAntigo6 = privateTextField6.getText();
              privateTextField6.setText(privateTextoAntigo6.toUpperCase());
              privateTextField7.requestFocus();
            }
            
          }
          else{
              privateTextoAntigo6 = "";
          }       
    }//GEN-LAST:event_privateTextField6KeyPressed

    private void privateTextField7KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_privateTextField7KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (privateTextoAntigo7.length() >= 0){
              privateTextField7.setText(privateTextoAntigo7.toUpperCase());
              privateTextField7.getParent().requestFocusInWindow();

            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              privateTextField7.setText("");
            }
            else{
              privateTextoAntigo7 = privateTextField7.getText();
              privateTextField7.setText(privateTextoAntigo7.toUpperCase());
              privateTextField7.getParent().requestFocusInWindow();

            }
            
          }
        else{
              privateTextoAntigo7 = "";
        }       
    }//GEN-LAST:event_privateTextField7KeyPressed

    private void contadorTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contadorTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contadorTextFieldActionPerformed

    private void booleanTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booleanTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_booleanTextField1ActionPerformed

    private void booleanTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booleanTextField1KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (booleanTextoAntigo1.length() >= 0){
              booleanTextField1.setText(booleanTextoAntigo1.toUpperCase());
              objetoBooleanTextField62.requestFocus();
              booleanTextField1id = 1;
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              booleanTextField1.setText("");
            }
            else{
              booleanTextoAntigo1 = booleanTextField1.getText();
              booleanTextField1.setText(booleanTextoAntigo1.toUpperCase());
              objetoBooleanTextField62.requestFocus();
              booleanTextField1id = 1;
            }
            
        }
        else{
              booleanTextoAntigo1 = "";
          }       
    }//GEN-LAST:event_booleanTextField1KeyPressed

    private void booleanTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booleanTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_booleanTextField3ActionPerformed

    private void booleanTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booleanTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (booleanTextoAntigo3.length() >= 0){
              booleanTextField3.setText(booleanTextoAntigo3.toUpperCase());
              booleanTextField4.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              booleanTextField3.setText("");
            }
            else{
              booleanTextoAntigo3 = booleanTextField3.getText();
              booleanTextField3.setText(booleanTextoAntigo3.toUpperCase());
              booleanTextField4.requestFocus();
            }
            
          }
          else{
              booleanTextoAntigo3 = "";
          } 
    }//GEN-LAST:event_booleanTextField3KeyPressed

    private void booleanTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booleanTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_booleanTextField4ActionPerformed

    private void booleanTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booleanTextField4KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (booleanTextoAntigo4.length() >= 0){
              booleanTextField4.setText(booleanTextoAntigo4.toUpperCase());
              booleanTextField5.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              booleanTextField4.setText("");
            }
            else{
              booleanTextoAntigo4 = booleanTextField4.getText();
              booleanTextField4.setText(booleanTextoAntigo4.toUpperCase());
              booleanTextField5.requestFocus();
            }
            
          }
          else{
              booleanTextoAntigo4 = "";
          } 
    }//GEN-LAST:event_booleanTextField4KeyPressed

    private void booleanTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booleanTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_booleanTextField5ActionPerformed

    private void booleanTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booleanTextField5KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (booleanTextoAntigo5.length() >= 0){
              booleanTextField5.setText(booleanTextoAntigo5.toUpperCase());
              booleanTextField6.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              booleanTextField5.setText("");
            }
            else{
              booleanTextoAntigo5 = booleanTextField5.getText();
              booleanTextField5.setText(booleanTextoAntigo5.toUpperCase());
              booleanTextField6.requestFocus();
            }
            
          }
          else{
              booleanTextoAntigo5 = "";
          } 
    }//GEN-LAST:event_booleanTextField5KeyPressed

    private void booleanTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booleanTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_booleanTextField6ActionPerformed

    private void booleanTextField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booleanTextField6KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (booleanTextoAntigo6.length() >= 0){
              booleanTextField6.setText(booleanTextoAntigo6.toUpperCase());
              booleanTextField7.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              booleanTextField6.setText("");
            }
            else{
              booleanTextoAntigo6 = booleanTextField6.getText();
              booleanTextField6.setText(booleanTextoAntigo6.toUpperCase());
              booleanTextField7.requestFocus();
            }
            
          }
          else{
              booleanTextoAntigo6 = "";
          } 
    }//GEN-LAST:event_booleanTextField6KeyPressed

    private void booleanTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booleanTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_booleanTextField7ActionPerformed

    private void booleanTextField7KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booleanTextField7KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (booleanTextoAntigo7.length() >= 0){
              booleanTextField7.setText(booleanTextoAntigo7.toUpperCase());
              booleanTextField7.getParent().requestFocusInWindow();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              booleanTextField7.setText("");
            }
            else{
              booleanTextoAntigo7 = booleanTextField7.getText();
              booleanTextField7.setText(booleanTextoAntigo7.toUpperCase());
              booleanTextField7.getParent().requestFocusInWindow();
            }
            
          }
          else{
              booleanTextoAntigo7 = "";
          } 
    }//GEN-LAST:event_booleanTextField7KeyPressed

    private void repeticaoTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoTextField1KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (repeticaoTextoAntigo1.length() >= 0){
              repeticaoTextField1.setText(repeticaoTextoAntigo1.toUpperCase());
              repeticaoSelecaoTextField24.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoTextField1.setText("");
            }
            else{
              repeticaoTextoAntigo1 = repeticaoTextField1.getText();
              repeticaoTextField1.setText(repeticaoTextoAntigo1.toUpperCase());
              repeticaoSelecaoTextField24.requestFocus();
            }
            
          }
          else{
              repeticaoTextoAntigo1 = "";
          }       
    }//GEN-LAST:event_repeticaoTextField1KeyPressed

    private void repeticaoSelecaoTextField24KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoSelecaoTextField24KeyPressed
        if (selecaoTextField3id == 0){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (repeticaoTextoAntigo2.length() >= 0){
                  repeticaoSelecaoTextField24.setText(repeticaoTextoAntigo2.toUpperCase());
                  repeticaoTextField3.requestFocus();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  repeticaoSelecaoTextField24.setText("");
                }
                else{
                  repeticaoTextoAntigo2 = repeticaoSelecaoTextField24.getText();
                  repeticaoSelecaoTextField24.setText(repeticaoTextoAntigo2.toUpperCase());
                  repeticaoTextField3.requestFocus();
                }

              }
              else{
                  repeticaoTextoAntigo2 = "";
              }    
        }
        else {
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (repeticaoTextoAntigo2.length() >= 0){
              repeticaoSelecaoTextField24.setText(repeticaoTextoAntigo2.toUpperCase());
              selecaoTextField5.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoSelecaoTextField24.setText("");
            }
            else{
              repeticaoTextoAntigo2 = repeticaoSelecaoTextField24.getText();
              repeticaoSelecaoTextField24.setText(repeticaoTextoAntigo2.toUpperCase());
              selecaoTextField5.requestFocus();
            }
            
        }
        else{
              repeticaoTextoAntigo2 = "";
          } 
            
        }
        selecaoTextField3id = 0;
    }//GEN-LAST:event_repeticaoSelecaoTextField24KeyPressed

    private void repeticaoTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (repeticaoTextoAntigo3.length() >= 0){
              repeticaoTextField3.setText(repeticaoTextoAntigo3.toUpperCase());
              repeticaoTextField40.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoTextField3.setText("");
            }
            else{
              repeticaoTextoAntigo3 = repeticaoTextField3.getText();
              repeticaoTextField3.setText(repeticaoTextoAntigo3.toUpperCase());
              repeticaoTextField40.requestFocus();
            }
            
          }
          else{
              repeticaoTextoAntigo3 = "";
          }    
    }//GEN-LAST:event_repeticaoTextField3KeyPressed

    private void repeticaoTextField40KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoTextField40KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (repeticaoTextoAntigo4.length() >= 0){
              repeticaoTextField40.setText(repeticaoTextoAntigo4.toUpperCase());
              repeticaoTextField5.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoTextField40.setText("");
            }
            else{
              repeticaoTextoAntigo4 = repeticaoTextField40.getText();
              repeticaoTextField40.setText(repeticaoTextoAntigo4.toUpperCase());
              repeticaoTextField5.requestFocus();
            }
            
          }
          else{
              repeticaoTextoAntigo4 = "";
          }    
    }//GEN-LAST:event_repeticaoTextField40KeyPressed

    private void repeticaoTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoTextField5KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (repeticaoTextoAntigo5.length() >= 0){
              repeticaoTextField5.setText(repeticaoTextoAntigo5.toUpperCase());
              repeticaoTextField5id = 1;
              repeticaoIntegerTextField61.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoTextField5.setText("");
            }
            else{
              repeticaoTextoAntigo5 = repeticaoTextField5.getText();
              repeticaoTextField5.setText(repeticaoTextoAntigo5.toUpperCase());
              repeticaoTextField5id = 1;
              repeticaoIntegerTextField61.requestFocus();
            }
            
          }
          else{
              repeticaoTextoAntigo5 = "";
          }    
    }//GEN-LAST:event_repeticaoTextField5KeyPressed

    private void repeticaoIntegerTextField61KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoIntegerTextField61KeyPressed
        if (repeticaoTextField5id == 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (repeticaoTextoAntigo6.length() >= 0){
                  repeticaoIntegerTextField61.setText(repeticaoTextoAntigo6.toUpperCase());
                  repeticaoTextField7.requestFocus();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  repeticaoIntegerTextField61.setText("");
                }
                else{
                  repeticaoTextoAntigo6 = repeticaoIntegerTextField61.getText();
                  repeticaoIntegerTextField61.setText(repeticaoTextoAntigo6.toUpperCase());
                  repeticaoTextField7.requestFocus();
                }

              }
              else{
                  repeticaoTextoAntigo6 = "";
              } 
        }
        else {
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (repeticaoTextoAntigo6.length() >= 0){
              repeticaoIntegerTextField61.setText(repeticaoTextoAntigo6.toUpperCase());
              integerTextField2.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoIntegerTextField61.setText("");
            }
            else{
              repeticaoTextoAntigo6 = repeticaoIntegerTextField61.getText();
              repeticaoIntegerTextField61.setText(repeticaoTextoAntigo6.toUpperCase());
              integerTextField2.requestFocus();
            }
            
          }
          else{
              repeticaoTextoAntigo1 = "";
          }       
        }
        repeticaoTextField5id = 0;
    }//GEN-LAST:event_repeticaoIntegerTextField61KeyPressed

    private void repeticaoTextField7KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoTextField7KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (repeticaoTextoAntigo7.length() >= 0){
              repeticaoTextField7.setText(repeticaoTextoAntigo7.toUpperCase());
              repeticaoTextField8.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoTextField7.setText("");
            }
            else{
              repeticaoTextoAntigo7 = repeticaoTextField7.getText();
              repeticaoTextField7.setText(repeticaoTextoAntigo7.toUpperCase());
              repeticaoTextField8.requestFocus();
            }
            
          }
          else{
              repeticaoTextoAntigo7 = "";
          } 
    }//GEN-LAST:event_repeticaoTextField7KeyPressed

    private void repeticaoTextField8KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repeticaoTextField8KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (repeticaoTextoAntigo8.length() >= 0){
              repeticaoTextField8.setText(repeticaoTextoAntigo8.toUpperCase());
              repeticaoMetodoTextField96.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              repeticaoTextField8.setText("");
            }
            else{
              repeticaoTextoAntigo8 = repeticaoTextField8.getText();
              repeticaoTextField8.setText(repeticaoTextoAntigo8.toUpperCase());
              repeticaoMetodoTextField96.requestFocus();
            }
            
          }
          else{
              repeticaoTextoAntigo8 = "";
          } 
    }//GEN-LAST:event_repeticaoTextField8KeyPressed

    private void integerTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_integerTextField2KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (integerTextoAntigo2.length() >= 0){
              integerTextField2.setText(integerTextoAntigo2.toUpperCase());
              integerTextField3.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              integerTextField2.setText("");
            }
            else{
              integerTextoAntigo2 = integerTextField2.getText();
              integerTextField2.setText(integerTextoAntigo2.toUpperCase());
              integerTextField3.requestFocus();
            }
            
          }
          else{
              integerTextoAntigo2 = "";
          }       
    }//GEN-LAST:event_integerTextField2KeyPressed

    private void integerTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_integerTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (integerTextoAntigo3.length() >= 0){
              integerTextField3.setText(integerTextoAntigo3.toUpperCase());
              integerTextField4.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              integerTextField3.setText("");
            }
            else{
              integerTextoAntigo3 = integerTextField3.getText();
              integerTextField3.setText(integerTextoAntigo3.toUpperCase());
              integerTextField4.requestFocus();
            }
            
          }
          else{
              integerTextoAntigo3 = "";
          }       
    }//GEN-LAST:event_integerTextField3KeyPressed

    private void integerTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_integerTextField4KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (integerTextoAntigo4.length() >= 0){
              integerTextField4.setText(integerTextoAntigo4.toUpperCase());
              integerTextField5.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              integerTextField4.setText("");
            }
            else{
              integerTextoAntigo4 = integerTextField4.getText();
              integerTextField4.setText(integerTextoAntigo4.toUpperCase());
              integerTextField5.requestFocus();
            }
            
          }
          else{
              integerTextoAntigo4 = "";
          }       
    }//GEN-LAST:event_integerTextField4KeyPressed

    private void integerTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_integerTextField5KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (integerTextoAntigo5.length() >= 0){
              integerTextField5.setText(integerTextoAntigo5.toUpperCase());
              integerTextField6.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              integerTextField5.setText("");
            }
            else{
              integerTextoAntigo5 = integerTextField5.getText();
              integerTextField5.setText(integerTextoAntigo5.toUpperCase());
              integerTextField6.requestFocus();
            }
            
          }
          else{
              integerTextoAntigo5 = "";
          }       
    }//GEN-LAST:event_integerTextField5KeyPressed

    private void integerTextField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_integerTextField6KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (integerTextoAntigo6.length() >= 0){
              integerTextField6.setText(integerTextoAntigo6.toUpperCase());
              shortIntegerTextField47.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              integerTextField6.setText("");
            }
            else{
              integerTextoAntigo6 = integerTextField6.getText();
              integerTextField6.setText(integerTextoAntigo6.toUpperCase());
              shortIntegerTextField47.requestFocus();
            }
            
          }
          else{
              integerTextoAntigo6 = "";
          }       
    }//GEN-LAST:event_integerTextField6KeyPressed

    private void shortIntegerTextField47KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_shortIntegerTextField47KeyPressed
        if (shortTextField3id != 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (integerTextoAntigo7.length() >= 0){
                  shortIntegerTextField47.setText(integerTextoAntigo7.toUpperCase());
                  shortIntegerTextField47.getParent().requestFocusInWindow();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  shortIntegerTextField47.setText("");
                }
                else{
                  integerTextoAntigo7 = shortIntegerTextField47.getText();
                  shortIntegerTextField47.setText(integerTextoAntigo7.toUpperCase());
                  shortIntegerTextField47.getParent().requestFocusInWindow();
                }

              }
              else{
                  integerTextoAntigo7 = "";
              }       
        }
        else {
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (integerTextoAntigo7.length() >= 0){
                  shortIntegerTextField47.setText(integerTextoAntigo7.toUpperCase());
                  shortTextField5.requestFocus();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  shortIntegerTextField47.setText("");
                }
                else{
                  integerTextoAntigo7 = shortIntegerTextField47.getText();
                  shortIntegerTextField47.setText(integerTextoAntigo7.toUpperCase());
                  shortTextField5.requestFocus();
                }

              }
              else{
                  integerTextoAntigo7 = "";
              }
        }
    }//GEN-LAST:event_shortIntegerTextField47KeyPressed

    private void selecaoTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_selecaoTextField1KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (selecaoTextoAntigo1.length() >= 0){
              selecaoTextField1.setText(selecaoTextoAntigo1.toUpperCase());
              selecaoTextField2.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              selecaoTextField1.setText("");
            }
            else{
              selecaoTextoAntigo1 = selecaoTextField1.getText();
              selecaoTextField1.setText(selecaoTextoAntigo1.toUpperCase());
              selecaoTextField2.requestFocus();
            }
            
        }
        else{
              selecaoTextoAntigo1 = "";
          }     
    }//GEN-LAST:event_selecaoTextField1KeyPressed

    private void selecaoTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_selecaoTextField2KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (selecaoTextoAntigo2.length() >= 0){
              selecaoTextField2.setText(selecaoTextoAntigo2.toUpperCase());
              selecaoTextField3.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              selecaoTextField2.setText("");
            }
            else{
              selecaoTextoAntigo2 = selecaoTextField2.getText();
              selecaoTextField2.setText(selecaoTextoAntigo2.toUpperCase());
              selecaoTextField3.requestFocus();
            }
            
        }
        else{
              selecaoTextoAntigo2 = "";
          }     
    }//GEN-LAST:event_selecaoTextField2KeyPressed

    private void selecaoTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_selecaoTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (selecaoTextoAntigo3.length() >= 0){
              selecaoTextField3.setText(selecaoTextoAntigo3.toUpperCase());
              selecaoTextField3id = 1;
              repeticaoSelecaoTextField24.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              selecaoTextField3.setText("");
            }
            else{
              selecaoTextoAntigo3 = selecaoTextField3.getText();
              selecaoTextField3.setText(selecaoTextoAntigo3.toUpperCase());
              selecaoTextField3id = 1;
              repeticaoSelecaoTextField24.requestFocus();
            }
            
        }
        else{
              selecaoTextoAntigo3 = "";
          }     
    }//GEN-LAST:event_selecaoTextField3KeyPressed

    private void selecaoTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_selecaoTextField5KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (selecaoTextoAntigo5.length() >= 0){
              selecaoTextField5.setText(selecaoTextoAntigo5.toUpperCase());
              selecaoTextField6.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              selecaoTextField5.setText("");
            }
            else{
              selecaoTextoAntigo5 = selecaoTextField5.getText();
              selecaoTextField5.setText(selecaoTextoAntigo5.toUpperCase());
              selecaoTextField6.requestFocus();
            }
            
        }
        else{
              selecaoTextoAntigo5 = "";
          }   
    }//GEN-LAST:event_selecaoTextField5KeyPressed

    private void selecaoTextField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_selecaoTextField6KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (selecaoTextoAntigo6.length() >= 0){
              selecaoTextField6.setText(selecaoTextoAntigo6.toUpperCase());
              longSelecaoTextField27.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              selecaoTextField6.setText("");
            }
            else{
              selecaoTextoAntigo6 = selecaoTextField6.getText();
              selecaoTextField6.setText(selecaoTextoAntigo6.toUpperCase());
              longSelecaoTextField27.requestFocus();
            }
            
        }
        else{
              selecaoTextoAntigo6 = "";
          }   
    }//GEN-LAST:event_selecaoTextField6KeyPressed

    private void longSelecaoTextField27KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_longSelecaoTextField27KeyPressed
        if(longTextField1id != 1){
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (selecaoTextoAntigo7.length() >= 0){
                  longSelecaoTextField27.setText(selecaoTextoAntigo7.toUpperCase());
                  shortIntegerTextField47.getParent().requestFocusInWindow();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  longSelecaoTextField27.setText("");
                }
                else{
                  selecaoTextoAntigo7 = longSelecaoTextField27.getText();
                  longSelecaoTextField27.setText(selecaoTextoAntigo7.toUpperCase());
                  shortIntegerTextField47.getParent().requestFocusInWindow();
                }

            }
            else{
                  selecaoTextoAntigo7 = "";
              } 
        }
        else{
            if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
                if (selecaoTextoAntigo7.length() >= 0){
                  longSelecaoTextField27.setText(selecaoTextoAntigo7.toUpperCase());
                  longTextField3.requestFocus();
                }
                char keyChar = evt.getKeyChar();
                if (!Character.isLetterOrDigit(keyChar)){
                  longSelecaoTextField27.setText("");
                }
                else{
                  selecaoTextoAntigo7 = longSelecaoTextField27.getText();
                  longSelecaoTextField27.setText(selecaoTextoAntigo7.toUpperCase());
                  longTextField3.requestFocus();
                }

            }
            else{
                  selecaoTextoAntigo7 = "";
              } 
        }
        longTextField1id = 0;
    }//GEN-LAST:event_longSelecaoTextField27KeyPressed

    private void longTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_longTextField1KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (longTextoAntigo1.length() >= 0){
              longTextField1.setText(longTextoAntigo1.toUpperCase());
              longTextField1id = 1;
              longSelecaoTextField27.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              longTextField1.setText("");
            }
            else{
              longTextoAntigo1 = longTextField1.getText();
              longTextField1.setText(longTextoAntigo1.toUpperCase());
              longTextField1id = 1;
              longSelecaoTextField27.requestFocus();
            }
            
        }
        else{
              longTextoAntigo1 = "";
          }     
    }//GEN-LAST:event_longTextField1KeyPressed

    private void longTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_longTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (longTextoAntigo3.length() >= 0){
              longTextField3.setText(longTextoAntigo3.toUpperCase());
              longTextField4.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              longTextField3.setText("");
            }
            else{
              longTextoAntigo3 = longTextField3.getText();
              longTextField3.setText(longTextoAntigo3.toUpperCase());
              longTextField4.requestFocus();
            }
            
        }
        else{
              longTextoAntigo3 = "";
          }     
    }//GEN-LAST:event_longTextField3KeyPressed

    private void longTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_longTextField4KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (longTextoAntigo4.length() >= 0){
              longTextField4.setText(longTextoAntigo4.toUpperCase());
              longTextField4.getParent().requestFocusInWindow();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              longTextField4.setText("");
            }
            else{
              longTextoAntigo4 = longTextField4.getText();
              longTextField4.setText(longTextoAntigo4.toUpperCase());
              longTextField4.getParent().requestFocusInWindow();
            }
            
        }
        else{
              longTextoAntigo4 = "";
          }     
    }//GEN-LAST:event_longTextField4KeyPressed

    private void shortTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_shortTextField1KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (shortTextoAntigo1.length() >= 0){
              shortTextField1.setText(shortTextoAntigo1.toUpperCase());
              shortTextField2.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              shortTextField1.setText("");
            }
            else{
              shortTextoAntigo1 = shortTextField1.getText();
              shortTextField1.setText(shortTextoAntigo1.toUpperCase());
              shortTextField2.requestFocus();
            }
            
        }
        else{
              shortTextoAntigo1 = "";
          }     
    }//GEN-LAST:event_shortTextField1KeyPressed

    private void shortTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_shortTextField2KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (shortTextoAntigo2.length() >= 0){
              shortTextField2.setText(shortTextoAntigo2.toUpperCase());
              shortTextField3.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              shortTextField2.setText("");
            }
            else{
              shortTextoAntigo2 = shortTextField2.getText();
              shortTextField2.setText(shortTextoAntigo2.toUpperCase());
              shortTextField3.requestFocus();
            }
            
        }
        else{
              shortTextoAntigo2 = "";
          }     
    }//GEN-LAST:event_shortTextField2KeyPressed

    private void shortTextField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_shortTextField5KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (shortTextoAntigo5.length() >= 0){
              shortTextField5.setText(shortTextoAntigo5.toUpperCase());
              shortTextField3.getParent().requestFocusInWindow();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              shortTextField5.setText("");
            }
            else{
              shortTextoAntigo5 = shortTextField5.getText();
              shortTextField5.setText(shortTextoAntigo5.toUpperCase());
              shortTextField3.getParent().requestFocusInWindow();
            }
            
        }
        else{
              shortTextoAntigo5 = "";
          }    
    }//GEN-LAST:event_shortTextField5KeyPressed

    private void shortTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_shortTextField3KeyPressed
        if(evt.getKeyCode() != KeyEvent.VK_BACK_SPACE){
            if (shortTextoAntigo3.length() >= 0){
              shortTextField3.setText(shortTextoAntigo3.toUpperCase());
              shortTextField3id = 1;
              shortIntegerTextField47.requestFocus();
            }
            char keyChar = evt.getKeyChar();
            if (!Character.isLetterOrDigit(keyChar)){
              shortTextField3.setText("");
            }
            else{
              shortTextoAntigo3 = shortTextField3.getText();
              shortTextField3.setText(shortTextoAntigo3.toUpperCase());
              shortTextField3id = 1;
              shortIntegerTextField47.requestFocus();
            }
            
        }
        else{
              shortTextoAntigo3 = "";
          }     
    }//GEN-LAST:event_shortTextField3KeyPressed

    private void dicasButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dicasButtonActionPerformed
        var dt = new DicasTela();
        dt.setVisible(true);
        
    }//GEN-LAST:event_dicasButtonActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Nivel1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Nivel1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Nivel1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Nivel1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Nivel1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField booleanTextField1;
    private javax.swing.JTextField booleanTextField3;
    private javax.swing.JTextField booleanTextField4;
    private javax.swing.JTextField booleanTextField5;
    private javax.swing.JTextField booleanTextField6;
    private javax.swing.JTextField booleanTextField7;
    private javax.swing.JTextField camelcaseHerancaTextField27;
    private javax.swing.JTextField camelcaseMetodoTextField31;
    private javax.swing.JTextField camelcaseTextField1;
    private javax.swing.JTextField camelcaseTextField4;
    private javax.swing.JTextField camelcaseTextField5;
    private javax.swing.JTextField camelcaseTextField6;
    private javax.swing.JTextField camelcaseTextField7;
    private javax.swing.JTextField camelcaseTextField9;
    private javax.swing.JTextField classeCamelcaseTextField48;
    private javax.swing.JTextField classeTextField1;
    private javax.swing.JTextField classeTextField2;
    private javax.swing.JTextField classeTextField3;
    private javax.swing.JTextField classeTextField5;
    private javax.swing.JTextField contadorTextField;
    private javax.swing.JButton dicasButton;
    private javax.swing.JButton finalizarButton;
    private javax.swing.JTextField herancaTextField1;
    private javax.swing.JTextField herancaTextField2;
    private javax.swing.JTextField herancaTextField3;
    private javax.swing.JTextField herancaTextField5;
    private javax.swing.JTextField herancaTextField6;
    private javax.swing.JTextField integerTextField2;
    private javax.swing.JTextField integerTextField3;
    private javax.swing.JTextField integerTextField4;
    private javax.swing.JTextField integerTextField5;
    private javax.swing.JTextField integerTextField6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JTextField longSelecaoTextField27;
    private javax.swing.JTextField longTextField1;
    private javax.swing.JTextField longTextField3;
    private javax.swing.JTextField longTextField4;
    private javax.swing.JTextField metodoTextField2;
    private javax.swing.JTextField metodoTextField3;
    private javax.swing.JTextField metodoTextField4;
    private javax.swing.JTextField metodoTextField5;
    private javax.swing.JTextField objetoBooleanTextField62;
    private javax.swing.JTextField objetoClasseTextField46;
    private javax.swing.JTextField objetoTextField1;
    private javax.swing.JTextField objetoTextField2;
    private javax.swing.JTextField objetoTextField3;
    private javax.swing.JTextField objetoTextField5;
    private javax.swing.JLabel planoFundoLabel;
    private javax.swing.JTextField privateHerancaTextField54;
    private javax.swing.JTextField privateTextField1;
    private javax.swing.JTextField privateTextField2;
    private javax.swing.JTextField privateTextField3;
    private javax.swing.JTextField privateTextField4;
    private javax.swing.JTextField privateTextField6;
    private javax.swing.JTextField privateTextField7;
    private javax.swing.JTextField repeticaoIntegerTextField61;
    private javax.swing.JTextField repeticaoMetodoTextField96;
    private javax.swing.JTextField repeticaoSelecaoTextField24;
    private javax.swing.JTextField repeticaoTextField1;
    private javax.swing.JTextField repeticaoTextField3;
    private javax.swing.JTextField repeticaoTextField4;
    private javax.swing.JTextField repeticaoTextField40;
    private javax.swing.JTextField repeticaoTextField5;
    private javax.swing.JTextField repeticaoTextField7;
    private javax.swing.JTextField repeticaoTextField8;
    private javax.swing.JTextField selecaoTextField1;
    private javax.swing.JTextField selecaoTextField2;
    private javax.swing.JTextField selecaoTextField3;
    private javax.swing.JTextField selecaoTextField5;
    private javax.swing.JTextField selecaoTextField6;
    private javax.swing.JTextField shortIntegerTextField47;
    private javax.swing.JTextField shortTextField1;
    private javax.swing.JTextField shortTextField2;
    private javax.swing.JTextField shortTextField3;
    private javax.swing.JTextField shortTextField5;
    // End of variables declaration//GEN-END:variables
}
