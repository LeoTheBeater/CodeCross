/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.codecross;

/**
 *
 * @author leona
 */
public class Ranking {
    private int fase;
    private String tempo;
    
    public Ranking() {
        
    }
     public Ranking(int fase, String tempo){
        this.fase = fase;
        this.tempo = tempo;
    }  
    public int getFase() {
        return fase;
    }

    public void setFase(int fase) {
        this.fase = fase;
    }

    public String getTempo() {
        return tempo;
    }

    public void setTempo(String tempo) {
        this.tempo = tempo;
    }
}

