/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.codecross;

/**
 * Classe responsável por criar conexões com o banco de dados.
 */
import java.sql.*;

public class ConnectionFactory {
    // Configurações do banco de dados
    private static String host = "ep-fragrant-pond-758456.us-east-2.aws.neon.tech";
    private static String porta = "5432";
    private static String db = "Code_Cross_DB";
    private static String usuario = "RaphaelKameoka";
    private static String senha = "0Pn5pMWvBikS";
    
    /**
     * Método para obter uma conexão com o banco de dados.
     * @return Conexão estabelecida com o banco de dados.
     * @throws Exception Caso ocorra algum erro na conexão.
     */
    public static Connection obterConexao() throws Exception{
        // Formata a URL de conexão com base nas configurações
        String s = String.format(
            "jdbc:postgresql://%s:%s/%s",
            host, porta, db
        );
        
        // Retorna uma conexão estabelecida com o banco de dados
        return DriverManager.getConnection(
            s, usuario, senha
        );
    }
}
