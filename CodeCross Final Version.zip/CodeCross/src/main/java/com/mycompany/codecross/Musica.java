/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.codecross;

/**
 *
 * @author leona
 */
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;


public class Musica{

    public Musica() {
       
    }
    public void musica(String song) {
        try {
            // Load the audio file
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(song));

            // Obtain a Clip to play the audio
            Clip clip = AudioSystem.getClip();

            // Open the AudioInputStream with the Clip
            clip.open(audioInputStream);

            // Start playing the audio
            clip.start();

            // Sleep for a while to allow the audio to play
            Thread.sleep(5000);

            // Stop the audio
            clip.stop();

            // Close the resources
            clip.close();
            audioInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}